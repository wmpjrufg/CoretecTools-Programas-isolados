function[Kelg]=MatrizRigidezGlobal(Kel,Rel)

    Kelg=Rel'*Kel*Rel;


end
